package lab04.Activity;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.Toast;

import com.example.lab04.R;

import lab04.AccesoDatos.ModeloDeDatos;
import lab04.LogicaNegocio.Profesor;
import lab04.LogicaNegocio.Carrera;

public class ProfesorActivity extends AppCompatActivity {
    static String modo = "";
    private SearchView searchView;
    private FloatingActionButton fab;
    private ModeloDeDatos model;
    private FloatingActionButton fBtn;
    private boolean editable = true;

    private EditText nombre;
    private EditText cedula;
    private AutoCompleteTextView mEmail;
    private  EditText Telefono;
    private View mLoginFormView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumno);
        Bundle bundle = getIntent().getExtras();
        String ced = bundle.getString("cedulaProf");
        ((EditText)findViewById(R.id.cedulaAddUpdProf)).setText(ced);
        editable = true;

        // button check
        fBtn = findViewById(R.id.addUpdAlumnoBtn);

        //cleaning stuff
        nombre = findViewById(R.id.nombreAddUpdProf);
        cedula = findViewById(R.id.cedulaAddUpdProf);
        mEmail = findViewById(R.id.emailAddUpdProf);
        Telefono=findViewById(R.id.telefonoAddUpdProf);

        //receiving data from admAlumnoActivity


            if (modo=="Editar") {   // is editing some row

                fBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        editProf();
                    }
                });
            } else {         // is adding new Carrera object
                //add new action
                fBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        addProf();
                    }
                });
            }

    }
    public void addProf() {
        if (validateForm()) {
            //do something
            Profesor profesor = new Profesor(Integer.parseInt(cedula.getText().toString()),nombre.getText().toString(),30,Integer.parseInt(Telefono.getText().toString()),mEmail.getText().toString());
            LoginActivity.DATOS.getProfesores().add(profesor);
            Intent intent = new Intent(getBaseContext(), DrawerAdministrador.class);
            startActivity(intent);

            finish(); //prevent go back
        }
    }

    public void editProf() {
        if (validateForm()) {
            Profesor profesor = new Profesor(Integer.parseInt(cedula.getText().toString()),nombre.getText().toString(),30,Integer.parseInt(Telefono.getText().toString()),mEmail.getText().toString());
            LoginActivity.DATOS.actualizarProfesor(Integer.parseInt(cedula.getText().toString()),profesor);
            Intent intent = new Intent(getBaseContext(), DrawerAdministrador.class);
            startActivity(intent);
            finish(); //prevent go back
        }
    }

    public boolean validateForm() {
        int error = 0;
        if (TextUtils.isEmpty(this.nombre.getText())) {
            nombre.setError("Nombre requerido");
            error++;
        }
        if (TextUtils.isEmpty(this.cedula.getText())) {
            cedula.setError("Cedula requerida");
            error++;
        }
        if (TextUtils.isEmpty(this.mEmail.getText())) {
            mEmail.setError("Email requerido");
            error++;
        }
        if (TextUtils.isEmpty(this.Telefono.getText())) {
            Telefono.setError("Fecha requerido");
            error++;
        }
        if (error > 0) {
            Toast.makeText(getApplicationContext(), "Algunos errores", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
    @Override
    public void onBackPressed() {
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            return;
        }if(modo=="Agregar"){
            Intent a = new Intent(this, DrawerAdministrador.class);
            a.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(a);
            super.onBackPressed();}
    }
}
