package lab04.Activity;

import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Message;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.os.Bundle;
import com.example.lab04.R;
import android.content.Context;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import lab04.AccesoDatos.ModeloDeDatos;
import lab04.LogicaNegocio.Alumno;
import lab04.LogicaNegocio.Carrera;
import lab04.LogicaNegocio.Usuario;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.Manifest.permission.READ_CONTACTS;


public class AlumnoActivity extends AppCompatActivity {
    private static final int REQUEST_READ_CONTACTS = 0;
    static String modo = "";
    private SearchView searchView;
    private FloatingActionButton fab;
    private ModeloDeDatos model;
    private FloatingActionButton fBtn;
    private boolean editable = true;

    private Alumno alumno;

    private EditText nombre;
    private EditText cedula;
    private AutoCompleteTextView mEmail;
    private EditText FechaNac;
    private EditText carrera;
    private View mLoginFormView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alumno);
        Bundle bundle = getIntent().getExtras();
        String ced = bundle.getString("cedulaAl");
        ((EditText)findViewById(R.id.cedulaAddUpdAlum)).setText(ced);
        editable = true;

        // button check
        fBtn = findViewById(R.id.addUpdAlumnoBtn);

        //cleaning stuff
        nombre = findViewById(R.id.nombreAddUpdAlum);
        cedula = findViewById(R.id.cedulaAddUpdAlum);
        mEmail = findViewById(R.id.emailAddUpdAlum);
        FechaNac=findViewById(R.id.fechaAddUpdAlum);
        carrera =findViewById(R.id.carreraAddUpdAlum);

        //receiving data from admAlumnoActivity

            if (modo=="Editar") {   // is editing some row
                fBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        editAlumno();
                    }
                });
            } else {         // is adding new Carrera object
                //add new action
                fBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        addAlumno();
                    }
                });
            }

    }
    public void addAlumno() {
        if (validateForm()) {
            //do something
            Carrera carr= LoginActivity.DATOS.getCarreraXNombre(carrera.getText().toString());
            Alumno alumno = new Alumno(Integer.parseInt(cedula.getText().toString()),nombre.getText().toString(),FechaNac.getText().toString(),20,mEmail.getText().toString(),carr);
            LoginActivity.DATOS.getAlumnos().add(alumno);
            Intent intent = new Intent(getBaseContext(), DrawerAdministrador.class);
            startActivity(intent);

            finish(); //prevent go back
        }
    }

    public void editAlumno() {
        if (validateForm()) {
            Carrera carr= LoginActivity.DATOS.getCarreraXNombre(carrera.getText().toString());
            Alumno alumno = new Alumno(Integer.parseInt(cedula.getText().toString()),nombre.getText().toString(),FechaNac.getText().toString(),20,mEmail.getText().toString(),carr);
            LoginActivity.DATOS.actualizarEstudiante(Integer.parseInt(cedula.getText().toString()),alumno);
            Intent intent = new Intent(getBaseContext(), DrawerAdministrador.class);
            startActivity(intent);
            finish(); //prevent go back
        }
    }

    public boolean validateForm() {
        int error = 0;
        if (TextUtils.isEmpty(this.nombre.getText())) {
            nombre.setError("Nombre requerido");
            error++;
        }
        if (TextUtils.isEmpty(this.cedula.getText())) {
            cedula.setError("Cedula requerida");
            error++;
        }
        if (TextUtils.isEmpty(this.mEmail.getText())) {
            mEmail.setError("Email requerido");
            error++;
        }
        if (TextUtils.isEmpty(this.FechaNac.getText())) {
            FechaNac.setError("Fecha requerido");
            error++;
        }
        if (TextUtils.isEmpty(this.carrera.getText())) {
            carrera.setError("Carrera requerido");
            error++;
        }
        if (error > 0) {
            Toast.makeText(getApplicationContext(), "Algunos errores", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
    @Override
    public void onBackPressed() {
        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            return;
        }if(modo=="Agregar"){
        Intent a = new Intent(this, DrawerAdministrador.class);
        a.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(a);
        super.onBackPressed();}
    }


}
