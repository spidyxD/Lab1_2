package lab04.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.example.lab04.R;

public class SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
}
