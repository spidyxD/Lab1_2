package lab04.LogicaNegocio;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
*/
public class Profesor extends Persona
{
    public int telefono;

    public Profesor(int cedula, String nombre , int edad , int telefono , String email) {
        super(nombre, cedula, email, edad);
        this.telefono=telefono;
    }
    public Profesor(){}
    public Profesor(int telefono, String nombre, int cedula, String email, int userN,String correo, int edad) {

        this.telefono = telefono;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCedula() {
        return cedula;
    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

}

