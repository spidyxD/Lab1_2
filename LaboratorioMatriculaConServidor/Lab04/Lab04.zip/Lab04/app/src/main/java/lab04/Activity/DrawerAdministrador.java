package lab04.Activity;

import android.content.Context;
import android.os.Bundle;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import com.example.lab04.R;

import lab04.LogicaNegocio.Alumno;

public class DrawerAdministrador extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private static final int REQUEST_READ_CONTACTS = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_drawer_administrador);
        Bundle bundle = getIntent().getExtras();
        String ced= bundle.getString("administradorCedula");
        TextView cedula= (TextView)findViewById(R.id.perfil_cedulaAdmin);
        cedula.setText(ced);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        //setContentView(R.layout.content_drawer_administrador);

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.drawer_administrador, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        SharedPreferences prefs = this.getSharedPreferences(getString(R.string.preference_user_key), Context.MODE_PRIVATE);
        String defaultValue = getResources().getString(R.string.preference_user_key_default);
        String privilegio = prefs.getString(getString(R.string.preference_user_key), defaultValue);

            // Handle the camera action
        if (id == R.id.editPerfilAdmin) {
            Toast.makeText(getApplicationContext(), "Editar Perfil", Toast.LENGTH_SHORT).show();
            abrirEditarPerfil();
        } else if (id == R.id.nav_logout) {
            Toast.makeText(getApplicationContext(), "Log Out", Toast.LENGTH_SHORT).show();
            abrirLogin();
        } else if (id == R.id.addStudents) {
            Toast.makeText(getApplicationContext(), "Agregar Alumnos", Toast.LENGTH_SHORT).show();
            abrirAddStudents();

        } else if (id == R.id.buscarEstudiantes) {
            Toast.makeText(getApplicationContext(), "Busqueda de Alumnos", Toast.LENGTH_SHORT).show();
            abrirSearchStudents();

        } else if (id == R.id.addProfesores) {
            Toast.makeText(getApplicationContext(), "Agregar Profesores", Toast.LENGTH_SHORT).show();
            abrirAddProfes();

        }else if (id == R.id.buscarProfesores) {
            Toast.makeText(getApplicationContext(), "Busqueda de Profesores", Toast.LENGTH_SHORT).show();
            abrirSearchProfes();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void abrirLogin() {
        finish();
        Intent a = new Intent(this, LoginActivity.class);
        startActivity(a);
    }
    public void abrirEditarPerfil() {
       // finish();

        Intent a = new Intent(this, AdministradorActivity.class);
        startActivity(a);
    }
    public void abrirAddStudents() {
        // finish();
        AlumnoActivity.modo="Agregar";
        Intent a = new Intent(this, AlumnoActivity.class);

        startActivity(a);
    }
    public void abrirAddProfes() {
        // finish();
        ProfesorActivity.modo="Agregar";
        Intent a = new Intent(this, ProfesorActivity.class);
        startActivity(a);
    }
    public void abrirSearchStudents() {
        // finish();
        Intent a = new Intent(this, SearchActivity.class);
        startActivity(a);
    }
    public void abrirSearchProfes() {
        // finish();
        Intent a = new Intent(this, SearchActivity.class);
        startActivity(a);
    }

}
